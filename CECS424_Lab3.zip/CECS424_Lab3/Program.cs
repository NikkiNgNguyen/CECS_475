﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Text;

namespace CECS424_Lab3
{

    class Program
    {
        public static void Main(string[] args)
        {
            Stock stock1 = new Stock("Technology", 160, 5, 15);
            Stock stock2 = new Stock("Retail", 30, 2, 6);
            Stock stock3 = new Stock("Banking", 90, 4, 10);
            Stock stock4 = new Stock("Commodity", 500, 20, 50);

            StockBroker b1 = new StockBroker("Broker 1");
            b1.AddStock(stock1);
            b1.AddStock(stock2);

            StockBroker b2 = new StockBroker("Broker 2");
            b2.AddStock(stock1);
            b2.AddStock(stock3);
            b2.AddStock(stock4);

            StockBroker b3 = new StockBroker("Broker 3");
            b3.AddStock(stock1);
            b3.AddStock(stock3);

            StockBroker b4 = new StockBroker("Broker 4");
            b4.AddStock(stock1);
            b4.AddStock(stock2);
            b4.AddStock(stock3);
            b4.AddStock(stock4);
        }
    }

    // Class EventData from EventArgs to store the event’s data: stock name, current stock value and number
    // of changes in the stock.
    public class EventData : EventArgs
    {
        public EventData(string name, int currentValue, int numOfChanges)
        {
            Name = name;
            CurrentValue = currentValue;
            NumOfChanges = numOfChanges;
        }
        public string Name { get; set; }
        public int CurrentValue { get; set; }
        public int NumOfChanges { get; set; }

    }

    class Stock
    {
        readonly string name;
        private int currentValue;
        readonly private int initialValue, notificationThreshold, maxChange;
        public int numOfChanges = 0;

        //Event: An event is a message sent by an object to signal the occurrence of an action. 
        //The action can be caused by user interaction, such as a button click, or it can result from some other program logic, such as changing a property’s value.
        protected virtual void onStockEvent(string name, int currentValue, int numOfChanges)
        {
            StockEvent?.Invoke(this, new EventData(name, currentValue, numOfChanges));
        }
        //EventHandler<TEventArgs> Delegate 
        public event EventHandler<EventData> StockEvent;

        public Stock(string name, int startingValue, int maxChange, int threshold)
        {
            this.name = name;
            initialValue = startingValue;
            currentValue = initialValue;
            this.maxChange = maxChange;
            notificationThreshold = threshold;
            //create a new thread
            Thread thread = new Thread(new ThreadStart(Activate));
            //change thread state to running
            thread.Start();
        }
        
        public void Activate()
        {
            for(; ; )
            {
                Thread.Sleep(500); // 1/2 second
                ChangeStockValue();
            }
        }

        public void ChangeStockValue()
        {
            Random r = new Random();
            currentValue += r.Next(1, maxChange);
            numOfChanges++;
            if((currentValue - initialValue) > notificationThreshold)
            {
                onStockEvent(name, currentValue, numOfChanges);
            }

        }
    }

    class StockBroker
    {
        //private static Mutex mutex = new Mutex();
        string brokerName;
        public static List<Stock> stocks = new List<Stock>();
        public static bool newFile = true;
        public StockBroker(string brokerName)
        {
            this.brokerName = brokerName;
        }

        public StockBroker(string brokerName, List<Stock> stocksList)
        {
            this.brokerName = brokerName;
            stocks = stocksList;
        }
        
        //Subscribe to the event
        public void AddStock(Stock stock)
        {
            stocks.Add(stock);
            stock.StockEvent += Notify;
        }

        ////Event Handler: To respond to an event, you define an event handler method in the event receiver.
        //public void Notify(object sender, EventData e)
        //{
        //    string header = "Broker".PadRight(15) + "Stock".PadRight(15) + "Value".PadRight(15) + "Changes".PadRight(15) + "Time";
        //    string path = @"C:\Users\nguye\source\repos\CECS424_Lab3\StocksOutput.txt";
        //    DateTime time = DateTime.Now;
        //    string contents = brokerName.PadRight(15) + e.Name.PadRight(15) + e.CurrentValue.ToString().PadRight(15) + e.NumOfChanges.ToString().PadRight(15) + time.ToString().PadRight(15);
        //    //blocks the current thread until the current WaitHandle receives the signal
        //    mutex.WaitOne();
        //    //if it's a new file, create it
        //    if (newFile == true)
        //    {
        //        File.Create(path).Close();
        //    }
        //    //append everything inside to the file
        //    using (StreamWriter sw = File.AppendText(path))
        //    {
        //        if (newFile == true)
        //        {
        //            Console.WriteLine(header);
        //            sw.WriteLine(header);
        //            newFile = false;
        //        }
        //        Console.WriteLine(contents);
        //        sw.WriteLine(contents);
        //        sw.Close();
        //    }
        //    //releases the mutex once
        //    mutex.ReleaseMutex();
        //}

        public async void Notify(object sender, EventData e)
        {
            string path = @"C:\Users\nguye\source\repos\CECS424_Lab3\StocksOutput.txt";
            DateTime time = DateTime.Now;
            string contents = (brokerName.PadRight(15) + e.Name.PadRight(15) + e.CurrentValue.ToString().PadRight(15) + e.NumOfChanges.ToString().PadRight(15) + time.ToString().PadRight(15));
            await WriteTextAsync(path, contents);
        }

        private async Task WriteTextAsync(string filepath, string text)
        {
            string newLine = "\n";
            string header = "Broker".PadRight(15) + "Stock".PadRight(15) + "Value".PadRight(15) + "Changes".PadRight(15) + "Time";

            //if it's a new file, create it
            if (newFile == true)
            {
                File.Create(filepath).Close();
            }
            //append everything inside to the file
            using (FileStream fs = new FileStream(filepath,
                        FileMode.Append, FileAccess.Write, FileShare.ReadWrite,
                        bufferSize: 4096, useAsync: true))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    if (newFile == true)
                    {
                        Console.Out.WriteLine(header);
                        sw.WriteLine(header);
                        newFile = false;
                        sw.Flush();
                    }
                    await Console.Out.WriteLineAsync(text);
                    await sw.WriteAsync(text);
                    await sw.WriteAsync(newLine);
                    sw.Flush();
                }
                fs.Dispose();
            }

        }

    }
}
