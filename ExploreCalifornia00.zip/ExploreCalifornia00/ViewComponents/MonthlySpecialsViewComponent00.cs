﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExploreCalifornia00.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExploreCalifornia00.ViewComponents
{
    public class MonthlySpecialsViewComponent00 : ViewComponent
    {
        private readonly BlogDataContext00 db;

        public MonthlySpecialsViewComponent00(BlogDataContext00 db)
        {
            this.db = db;
        }

        public IViewComponentResult Invoke()
        {
            var specials = db.MonthlySpecials.ToArray();
            return View(specials);
        }
    }
}
