﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ExploreCalifornia00.Models
{
    public class IdentityDataContext00 : IdentityDbContext<IdentityUser>
    {
        public IdentityDataContext00(DbContextOptions<IdentityDataContext00> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
    }
}
