﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExploreCalifornia00.Models
{
    public class FormattingService00
    {
        public string AsReadableDate(DateTime date)
        {
            return date.ToString("D");
        }
    }
}
