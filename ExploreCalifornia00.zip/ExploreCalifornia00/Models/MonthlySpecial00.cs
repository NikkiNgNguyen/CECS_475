using System;

namespace ExploreCalifornia00.Models
{
    public class MonthlySpecial00
    {
        public string Key { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
    }
}