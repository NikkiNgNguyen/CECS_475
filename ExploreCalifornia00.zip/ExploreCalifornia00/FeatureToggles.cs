﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExploreCalifornia00
{
    public class FeatureToggles
    {
        public bool DeveloperExceptions { get; set; }
    }
}
