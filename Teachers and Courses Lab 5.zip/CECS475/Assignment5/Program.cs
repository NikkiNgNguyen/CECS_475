﻿using BusinessLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Program
    {
        //----------------------------------------- Slots ------
        static BusinessLayer.BusinessLayer bl = new BusinessLayer.BusinessLayer();

        public static void Main(string[] args)
        {
            int homeAnswer = -1;
            do
            {
                homeAnswer = Menu();
                switch (homeAnswer){
                    case 1:
                        DisplayTeachers();
                        break;
                    case 2:
                        DisplayCoursesByTeacher();
                        break;
                    case 3:
                        AddTeacher();
                        break;
                    case 4:
                        UpdateTeacher();
                        break;
                    case 5:
                        RemoveTeacher();
                        break;
                    case 6:
                        DisplayCourses();
                        break;
                    case 7:
                        AddCourse();
                        break;
                    case 8:
                        UpdateCourse();
                        break;
                    case 9:
                        RemoveCourse();
                        break;
                    default:
                        break;
                }
            } while (homeAnswer != 0);
        }

               

        private static int ReadChoice()
        {
            string s = Console.ReadLine();
            return Convert.ToInt32(s);
        }

        private static int Menu()
        {
            Console.WriteLine("1.Display Teachers\n2.Display Courses by Teacher ID\n3.Add Teacher" +
                "\n4.Update Teacher\n5.Remove Teacher\n6.Display Courses\n7.Add Course" +
                "\n8.Update Course\n9.Remove Course\n0.Exit");
            var result = ReadChoice();
            return result;
        }

        private static void DisplayTeachers()
        {
            var teachers = bl.GetAllTeachers();
            Console.WriteLine("{0,-10}{1,-10}{2,-10}", "ID", "Name", "StandardID");
            foreach (Teacher teacher in teachers)
            {
                Console.WriteLine("{0,-10}{1,-10}{2,-10}", teacher.TeacherId, teacher.TeacherName, teacher.StandardId);
            }

        }

        private static void DisplayCoursesByTeacher()
        {
            Console.WriteLine("Enter teacher ID to view courses:");
            var id = ReadChoice();
            var teacher = bl.GetTeacherByID(id);
            if (teacher == null)
            {
                Console.WriteLine("Teacher doesn't exist!\n");
            }
            else
            {
                var courses = bl.GetCoursesByTeacher(id);
                Console.WriteLine("{0,-10}{1,-10}", "ID", "Name");
                foreach (Course course in courses)
                {
                    Console.WriteLine("{0,-10}{1,-10}", course.CourseId, course.CourseName);
                }
            }
        }
        private static void AddTeacher()
        {
            bool idAvailable = false;
            bool standardExists = false;
            var id = 0;
            var standardId = 0;
            do
            {
                Console.WriteLine("Enter in teacher ID:");
                id = ReadChoice();
                if(bl.GetTeacherByID(id) != null)
                {
                    Console.WriteLine("\nID already taken, try again!");
                }
                else
                {
                    idAvailable = true;
                }
            } while (!idAvailable);
            Console.WriteLine("Enter in teacher name:");
            var name = Console.ReadLine();
            do
            {
                Console.WriteLine("Enter in standard ID:");
                standardId = ReadChoice();
                if (bl.GetStandardByID(standardId) == null)
                {
                    Console.WriteLine("\nStandard doesn't exist, try again!");
                }
                else
                {
                    standardExists = true;
                }
            } while (!standardExists);

            Teacher newTeacher = new Teacher
            {
                TeacherId = id,
                TeacherName = name,
                StandardId = standardId
            };
            bl.AddTeacher(newTeacher);

            Console.WriteLine("\nTeacher {0} has been created!", name);
        }
        
        private static void UpdateTeacher()
        {
            var mainAnswer = 0;
            do
            {
                Console.WriteLine("1.Update teacher by id\n2.Update teachers by name");
                mainAnswer = ReadChoice();
            } while (mainAnswer != 1 && mainAnswer != 2);
            if(mainAnswer == 1)
            {
                Console.WriteLine("Enter teacher ID to update:");
                var id = ReadChoice();
                var teacher = bl.GetTeacherByID(id);
                if (teacher == null)
                {
                    Console.WriteLine("Teacher doesn't exist!\n");
                }
                else
                {
                    var menuAnswer = 0;
                    do
                    {
                        Console.WriteLine("1.Modify teacher name\n2.Modify teacher's standard");
                        menuAnswer = ReadChoice();
                    } while (menuAnswer != 1 && menuAnswer != 2);
                    if (menuAnswer == 1)
                    {
                        Console.WriteLine("Enter name:");
                        teacher.TeacherName = Console.ReadLine();
                    }
                    else
                    {
                        bool standardExists = false;
                        var standardId = 0;
                        do
                        {
                            Console.WriteLine("Enter in standard ID:");
                            standardId = ReadChoice();
                            if (bl.GetStandardByID(standardId) == null)
                            {
                                Console.WriteLine("\nStandard doesn't exist, try again!");
                            }
                            else
                            {
                                standardExists = true;
                            }
                        } while (!standardExists);
                        teacher.StandardId = standardId;
                    }
                    bl.UpdateTeacher(teacher);
                    Console.WriteLine("Teacher {0} updated!", teacher.TeacherName);
                }
            }
            else{
                Console.WriteLine("Enter teacher name to update:");
                var name = Console.ReadLine();
                var teachers = bl.GetTeachersByName(name);
                if (teachers == null)
                {
                    Console.WriteLine("Teacher doesn't exist!\n");
                }
                else
                {
                    var menuAnswer = 0;
                    do
                    {
                        Console.WriteLine("1.Modify teacher name\n2.Modify teacher's standard");
                        menuAnswer = ReadChoice();
                    } while (menuAnswer != 1 && menuAnswer != 2);
                    if (menuAnswer == 1)
                    {
                        Console.WriteLine("Enter name:");
                        var nameChange = Console.ReadLine();
                        foreach(Teacher teacher in teachers)
                        {
                            teacher.TeacherName = nameChange;
                            bl.UpdateTeacher(teacher);
                        }
                    }
                    else
                    {
                        bool standardExists = false;
                        var standardId = 0;
                        do
                        {
                            Console.WriteLine("Enter in standard ID:");
                            standardId = ReadChoice();
                            if (bl.GetStandardByID(standardId) == null)
                            {
                                Console.WriteLine("\nStandard doesn't exist, try again!");
                            }
                            else
                            {
                                standardExists = true;
                            }
                        } while (!standardExists);
                        foreach(Teacher teacher in teachers)
                        {
                            teacher.StandardId = standardId;
                            bl.UpdateTeacher(teacher);
                        }
                    }
                }
                Console.WriteLine("{0} teachers updated!", teachers.Count());
            }

        }

        private static void RemoveTeacher()
        {
            Console.WriteLine("Enter teacher ID to remove:");
            var id = ReadChoice();
            var teacher = bl.GetTeacherByID(id);
            if(teacher == null)
            {
                Console.WriteLine("Teacher doesn't exist!\n");
            }
            else
            {
                var removedCourses = bl.GetCoursesByTeacher(id);
                var courseList = removedCourses.ToList();
                foreach(Course course in courseList)
                {
                    bl.RemoveCourse(course);
                }
                bl.RemoveTeacher(teacher);
                Console.WriteLine("{0} has been deleted!", teacher.TeacherName);

            }

        }

        private static void DisplayCourses()
        {
            var courses = bl.GetAllCourses();
            Console.WriteLine("{0,-10}{1,-10}{2,-10}", "ID", "Name", "TeacherID");
            foreach (Course course in courses)
            {
                Console.WriteLine("{0,-10}{1,-10}{2,-10}", course.CourseId, course.CourseName, course.TeacherId);
            }
        }

        private static void AddCourse()
        {
            bool idAvailable = false;
            bool teacherExists = false;
            var id = 0;
            var teacherId = 0;
            do
            {
                Console.WriteLine("Enter in course ID:");
                id = ReadChoice();
                if (bl.GetCourseByID(id) != null)
                {
                    Console.WriteLine("\nID already taken, try again!");
                }
                else
                {
                    idAvailable = true;
                }
            } while (!idAvailable);
            Console.WriteLine("Enter in course name:");
            var name = Console.ReadLine();
            do
            {
                Console.WriteLine("Enter in teacher ID:");
                teacherId = ReadChoice();
                if (bl.GetTeacherByID(teacherId) == null)
                {
                    Console.WriteLine("\nTeacher doesn't exist, try again!");
                }
                else
                {
                    teacherExists = true;
                }
            } while (!teacherExists);

            Course newCourse = new Course
            {
                CourseId = id,
                CourseName = name,
                TeacherId = teacherId,
                Location = null
            };
            bl.AddCourse(newCourse);

            Console.WriteLine("\nCourse {0} has been created!", name);
        }

        private static void UpdateCourse()
        {
            var mainAnswer = 0;
            do
            {
                Console.WriteLine("1.Update course by id\n2.Update course by name");
                mainAnswer = ReadChoice();
            } while (mainAnswer != 1 && mainAnswer != 2);
            if(mainAnswer == 1)
            {
                var menuAnswer = 0;
                Console.WriteLine("Enter course ID to update:");
                var id = ReadChoice();
                var course = bl.GetCourseByID(id);
                if (course == null)
                {
                    Console.WriteLine("Course doesn't exist!\n");
                }
                else
                {
                    do
                    {
                        Console.WriteLine("1.Modify course name\n2.Modify course's teacher");
                        menuAnswer = ReadChoice();
                    } while (menuAnswer != 1 && menuAnswer != 2);
                    if (menuAnswer == 1)
                    {
                        Console.WriteLine("Enter name:");
                        course.CourseName = Console.ReadLine();
                    }
                    else
                    {
                        var teacherExists = false;
                        var teacherId = 0;
                        do
                        {
                            Console.WriteLine("Enter in teacher ID:");
                            teacherId = ReadChoice();
                            if (bl.GetTeacherByID(teacherId) == null)
                            {
                                Console.WriteLine("\nTeacher doesn't exist, try again!");
                            }
                            else
                            {
                                teacherExists = true;
                            }
                        } while (!teacherExists);
                        course.TeacherId = teacherId;
                    }
                    bl.UpdateCourse(course);
                    Console.WriteLine("Course {0} updated!", course.CourseName);
                }
            }
            else
            {
                Console.WriteLine("Enter course name to update:");
                var name = Console.ReadLine();
                var courses = bl.GetCoursesByName(name);
                if (courses == null)
                {
                    Console.WriteLine("Teacher doesn't exist!\n");
                }
                else
                {
                    var menuAnswer = 0;
                    do
                    {
                        Console.WriteLine("1.Modify course name\n2.Modify course's teacher");
                        menuAnswer = ReadChoice();
                    } while (menuAnswer != 1 && menuAnswer != 2);
                    if (menuAnswer == 1)
                    {
                        Console.WriteLine("Enter name:");
                        var nameChange = Console.ReadLine();
                        foreach (Course course in courses)
                        {
                            course.CourseName = nameChange;
                            bl.UpdateCourse(course);
                        }
                    }
                    else
                    {
                        bool teacherExists = false;
                        var teacherId = 0;
                        do
                        {
                            Console.WriteLine("Enter in teacher ID:");
                            teacherId = ReadChoice();
                            if (bl.GetTeacherByID(teacherId) == null)
                            {
                                Console.WriteLine("\nTeacher doesn't exist, try again!");
                            }
                            else
                            {
                                teacherExists = true;
                            }
                        } while (!teacherExists);
                        foreach (Course course in courses)
                        {
                            course.TeacherId = teacherId;
                            bl.UpdateCourse(course);
                        }
                    }
                }
                Console.WriteLine("{0} courses updated!", courses.Count());
            }
        }

        private static void RemoveCourse()
        {
            Console.WriteLine("Enter course ID to remove:");
            var id = ReadChoice();
            var course = bl.GetCourseByID(id);
            if (course == null)
            {
                Console.WriteLine("Course doesn't exist!\n");
            }
            else
            {
                bl.RemoveCourse(course);
                Console.WriteLine("{0} has been deleted!", course.CourseName);
            }

        }

    }

}
