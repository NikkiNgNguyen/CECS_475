﻿using CECS475_Lab3.Command;
using System;
using System.ComponentModel;
using System.Windows.Input;

namespace CECS475_Lab3.ViewModel
{
    public class ViewModel : INotifyPropertyChanged
    {
        public ICommand MyCommand { get; set; }
        public ICommand MyCommand2 { get; set; }
        public ICommand MyCommand3 { get; set; }

        public ICommand MyCommand4 { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }

        private string _number1;
        public string Number1
        {
            get { return _number1; }
            set { _number1 = value; OnPropertyChanged("Number1"); }
        }
        private string _number2;
        public string Number2
        {
            get { return _number2; }
            set { _number2 = value; OnPropertyChanged("Number2"); }
        }
        private string _result;
        public string Result
        {
            get { return _result; }
            set { _result = value; OnPropertyChanged("Result"); }
        }
        public ViewModel()
        {
            MyCommand = new RelayCommand(sum, canexecute);
            MyCommand2 = new RelayCommand(difference, canexecute);
            MyCommand3 = new RelayCommand(product, canexecute);
            MyCommand4 = new RelayCommand(quotient, canexecute);

        }

        private bool canexecute(object parameter)
        {
            if (!string.IsNullOrEmpty(Number1) && !string.IsNullOrEmpty(Number2))
            {
                return true;
            }
            return false;

        }
        private void sum(object parameter)
        {
            Result = (Convert.ToDouble(Number1) + Convert.ToDouble(Number2)).ToString();
        }
        private void difference(object parameter)
        {
            Result = (Convert.ToDouble(Number1) - Convert.ToDouble(Number2)).ToString();
        }
        private void product(object parameter)
        {
            Result = (Convert.ToDouble(Number1) * Convert.ToDouble(Number2)).ToString();
        }
        private void quotient(object parameter)
        {
            Result = (Convert.ToDouble(Number1) / Convert.ToDouble(Number2)).ToString();
        }
    }
}

