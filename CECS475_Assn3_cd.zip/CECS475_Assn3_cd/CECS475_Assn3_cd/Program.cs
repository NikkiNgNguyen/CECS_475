﻿/*Nikki Nguyen
 * 09/16/19
 * CECS 475 - 01
 * Assn 3 - Event Handler
 */
using System;

namespace CECS475_Assn3_cd
{
    class Program
    {
        static void Main(string[] args)
        {
            //output for part c
            Number myNumber = new Number(100000);
            myNumber.PrintMoney();
            myNumber.PrintNumber();

            //output for part d
            NumberPass myNumberPass = new NumberPass(100000);
            myNumberPass.PrintMoneyPass();
            myNumberPass.PrintNumberPass();
        }
    }

    //Event Listener - class subscribes to the event of the PrintHelper and defines the method 
    //NewNumIsHere that in turn fulfills the requirements of the EventHandler<NumInfoEventArgs> delegate
    //with paremeters of type object and NumInfoEventArgs
    class Number
    {
    private PrintHelper _printHelper;
        public Number(int val)
        {
            _value = val;

            _printHelper = new PrintHelper();
            //subscribe to beforePrintEvent event
            _printHelper.NewNumInfo += NewNumIsHere;
        }

        static void NewNumIsHere(object sender, EventArgs e)
        {
                Console.WriteLine("BeforPrintEventHandler: PrintHelper is going to print a value", EventArgs.Empty);
            }

        private int _value;

        public int Value
        {
            get { return _value; }
            set { _value = value; }
        }

        public void PrintMoney()
        {
            _printHelper.PrintMoney(_value);
        }

        public void PrintNumber()
        {
            _printHelper.PrintNumber(_value);
        }
    }

    //Event Publisher - offer subscription based on events
    public class PrintHelper
    {
        public event EventHandler NewNumInfo;
        public delegate void BeforePrint();

        public void PrintNumber(int num)
        {
            //call delegate method before going to print
            NewNumInfo?.Invoke(this, EventArgs.Empty);
            Console.WriteLine("Number: {0,-12:N0}", num);
        }

        public void PrintMoney(int money)
        {
            NewNumInfo?.Invoke(this, EventArgs.Empty);
            Console.WriteLine("Money: {0:C}", money);
        }

    }

    public class NumInfoEventArgsPass : EventArgs
    {
        public NumInfoEventArgsPass(string number)
        {
            NumberPass = number;
        }

        public string NumberPass { get; }
    }

    class NumberPass
    {
        private PrintHelperPass _printHelperPass;
        public NumberPass(int val)
        {
            _valuePass = val;

            _printHelperPass = new PrintHelperPass();
            //subscribe to beforePrintEvent event

            _printHelperPass.NewNumInfoPass += NewNumIsHerePass;
        }
        public void NewNumIsHerePass(object sender, NumInfoEventArgsPass e)
        {
            Console.WriteLine("BeforePintEvent fires from {0}", e.NumberPass);
        }
        
        private int _valuePass;
        public int ValuePass
        {
            get { return _valuePass; }
            set { _valuePass = value; }
        }
        public void PrintMoneyPass()
        {
            _printHelperPass.PrintMoneyPass(_valuePass);
        }
        public void PrintNumberPass()
        {
            _printHelperPass.PrintNumberPass(_valuePass);
        }
    }

    public class PrintHelperPass
    {
        public event EventHandler<NumInfoEventArgsPass> NewNumInfoPass;
        public delegate void BeforePrintPass(string message);

        public void PrintNumberPass(int num)
        {
            NewNumInfoPass?.Invoke(this, new NumInfoEventArgsPass("PrintNumber"));
            Console.WriteLine("Number: {0,-12:N0}", num);
        }

        public void PrintMoneyPass(int money)
        {
            NewNumInfoPass?.Invoke(this, new NumInfoEventArgsPass("PrintMoney"));
            Console.WriteLine("Money: {0:C}", money);
        }

    }

}

