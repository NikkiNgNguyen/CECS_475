﻿/*
* Nikki Nguyen
* 09/04/2019
* CECS 475 - 01
* Assignment 2
*/
using System;

namespace CECS475_Assn2
{
    class IntegerSet
    {
        //array size
        private const int SIZE = 101;
        //array that tells true or false 
        private bool[] mySet;

        //default constructor
        public IntegerSet()
        {
            mySet = new bool[SIZE];
        }

        //fill array
        public IntegerSet(int[] a)
        {
            mySet = new bool[SIZE];
            for(int i = 0; i < a.Length; i++)
            {
                if (a[i] >= 0 && a[i] <= 100)
                    InsertElement(a[i]);
            }
        }

        //all values that exist in both sets
        public IntegerSet Union(IntegerSet newSet)
        {
            IntegerSet tempSet = new IntegerSet();
            for(int i = 0; i < SIZE; i++)
            {
                if (mySet[i] == true || newSet.mySet[i] == true)
                    tempSet.InsertElement(i);
            }
            return tempSet;
        }

        //if value exists in both sets
        public IntegerSet Intersection(IntegerSet newSet)
        {
        IntegerSet tempSet = new IntegerSet();
            for(int i = 0; i < SIZE; i++)
            {
                if (mySet[i] == true && newSet.mySet[i] == true)
                    tempSet.InsertElement(i);
            }
            return tempSet;  
        }

        //inserts an element into set
        public void InsertElement(int k)
        {
            if (k < 0 || k > 100)
                Console.WriteLine("Number out of bounds. Between 0 - 100 only.");
            else
                mySet[k] = true;
            
        }

        //removes element from set
        public void DeleteElement(int m)
        {
            mySet[m] = false;
        }

        public override string ToString()
        {
            bool empty = true;
            String printSet = "";
            for(int i = 0; i < SIZE; i++)
            {
                if(mySet[i] == true){
                    printSet += (i + " ");
                    empty = false;
                }
            }
            if (empty == true)
                printSet += "---";
            return printSet;
        }

        //Check if sets are equal
        public bool IsEqualTo(IntegerSet newSet)
        {
            int i = 0;
            while(i < SIZE)
            {
                if (mySet[i] == newSet.mySet[i])
                    i++;
                else
                    return false;
            }
            return true;
        } 
    }

    class Driver
    {
        static void Main(string[] args)
        {
            // initialize two sets
            Console.WriteLine("Input Set A");
            IntegerSet set1 = InputSet();
            Console.WriteLine("\nInput Set B");
            IntegerSet set2 = InputSet();

            IntegerSet union = set1.Union(set2);
            IntegerSet intersection = set1.Intersection(set2);

            // prepare output
            Console.WriteLine("\nSet A contains elements:");
            Console.WriteLine(set1.ToString());
            Console.WriteLine("\nSet B contains elements:");
            Console.WriteLine(set2.ToString());
            Console.WriteLine(
            "\nUnion of Set A and Set B contains elements:");
            Console.WriteLine(union.ToString());
            Console.WriteLine(
            "\nIntersection of Set A and Set B contains elements:");
            Console.WriteLine(intersection.ToString());

            // test whether two sets are equal
            if (set1.IsEqualTo(set2))
                Console.WriteLine("\nSet A is equal to set B");
            else
                Console.WriteLine("\nSet A is not equal to set B");

            // test insert and delete
            Console.WriteLine("\nInserting 77 into set A...");
            set1.InsertElement(77);
            Console.WriteLine("\nSet A now contains elements:");
            Console.WriteLine(set1.ToString());

            Console.WriteLine("\nDeleting 77 from set A...");
            set1.DeleteElement(77);
            Console.WriteLine("\nSet A now contains elements:");
            Console.WriteLine(set1.ToString());

            // test constructor
            int[] intArray = { 25, 67, 2, 9, 99, 105, 45, -5, 100, 1 };
            IntegerSet set3 = new IntegerSet(intArray);

            Console.WriteLine("\nNew Set contains elements:");
            Console.WriteLine(set3.ToString());
        }

        //Function that lets user create new set and insert values into the set.
        public static IntegerSet InputSet()
        {
            IntegerSet userSet = new IntegerSet();
            Console.WriteLine("input values to add to array \n*Press any other key to stop*");
            while (int.TryParse(Console.ReadLine(), out int newValue))
            {
                userSet.InsertElement(newValue);
            }
            return userSet;
        }
    }
}
