﻿/* Audrey Kobayashi & Nikki Nguyen
 * CECS 475 - 01
 * 10/21/2019
 * Assignment 6
 */
using BusinessLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    public class Program
    {
        static UnitOfWork unitOfWork = new UnitOfWork(new SchoolDBEntities());   
        static BusinessLayer.BusinessLayer bl = new BusinessLayer.BusinessLayer(unitOfWork);
        //The main method handles the switch cases for the user's input - which method to call
        public static void Main(string[] args)
        {
            int choice = -1;
            do
            {
                choice = Menu();
                switch (choice)
                {
                    case 1:
                        DisplayTeachers();
                        break;
                    case 2:
                        AddTeacher();
                        break;
                    case 3:
                        UpdateTeacher();
                        break;
                    case 4:
                        DeleteTeacher();
                        break;
                    case 5:
                        DisplayCourses();
                        break;
                    case 6:
                        AddCourse();
                        break;
                    case 7:
                        UpdateCourse();
                        break;
                    case 8:
                        DeleteCourse();
                        break;
                    case 9:
                        DisplayCoursesByTeacherID();
                        break;
                    default:
                        break;
                }
            } while (choice != 0);
        }
        //Gets the user input and converts it to an integer
        private static int ReadChoice()
        {
            string s = Console.ReadLine();
            return Convert.ToInt32(s);
        }
        //The main menu displays the options the user has
        //Then gets the user's input
        private static int Menu()
        {
            Console.WriteLine("[    Teachers Table     ]\n" +
                              "1. Display Teachers\n" +
                              "2. Add Teacher\n" +
                              "3. Update Teacher\n" +
                              "4. Remove Teacher\n" +
                              "\n" +
                              "[    Courses Table      ]\n" +
                              "5. Display Courses\n" +
                              "6. Add Course\n" +
                              "7. Update Course\n" +
                              "8. Remove Course\n" +
                              "9. Display Courses by Teacher ID\n" +
                              "\n" +
                              "\n0. Exit");
            var option = ReadChoice();
            return option;
        }
        //Displays the ID, name, and standard ID for the corresponding teacher
        private static void DisplayTeachers()
        {
            var teachers = bl.GetAllTeachers();
            Console.WriteLine("{0,-15}{1,-15}{2,-15}", "ID", "Name", "StandardID");
            foreach(Teacher teacher in teachers)
            {
                Console.WriteLine("{0,-15}{1,-15}{2,-15}", teacher.TeacherId, teacher.TeacherName, teacher.StandardId);
            }

        }
        //Displays the course ID, name, and the teacher ID for the corresponding course
        private static void DisplayCourses()
        {
            var courses = bl.GetAllCourses();
            Console.WriteLine("{0,-15}{1,-15}{2,-15}", "ID", "Name", "TeacherID");
            foreach (Course course in courses)
            {
                Console.WriteLine("{0,-15}{1,-15}{2,-15}", course.CourseId, course.CourseName, course.TeacherId);
            }

        }
        //This method allows the user to input a new teacher
        //The teacher ID must be unique and not already in the system
        private static void AddTeacher()
        {
            bool teacherIdAvailable = false;
            bool standardExists = false;
            var teacherID = 0;
            var standardID = 0;
           //do
           //{
                //Reads the user's input for the new teacher ID
                //Console.WriteLine("Enter teacher ID:\n");
                //teacherID = ReadChoice();
                //Validates if the teacher ID is already existent, 
                //If they are not, loops until the user inputs a valid teacher ID
                //Else, allows the user to continue inputting the new teacher data
                /*if (bl.GetTeacherByID(teacherID) != null)
                {
                    Console.WriteLine("\nID already in use, try again!\n");
                }
                else
                {
                    teacherIdAvailable = true;
                }
            } while (!teacherIdAvailable);*/
            //Reads the user's input for the new teacher name
            Console.WriteLine("Enter teacher name:\n");
            var teacherName = Console.ReadLine();
            do
            {
                //Reads the user's input for the teacher's standard ID
                Console.WriteLine("Enter standard ID:\n");
                standardID = ReadChoice();
                //Validates if the teacher's standard ID is already existent
                //If the standard ID does not already exist, the user must input a valid standard ID
                if (bl.GetStandardByID(standardID) == null)
                {
                    Console.WriteLine("\nStandard does not exist, try again!");
                }
                else
                {
                    standardExists = true;
                }
            } while (!standardExists);
            //Creates the teacher object and adds the object to the list
            Teacher t = new Teacher
            {
                TeacherName = teacherName,
                StandardId = standardID
            };
            bl.AddTeacher(t);
            unitOfWork.Save();

            Console.WriteLine("\nTeacher {0} created!", teacherName);
        }
        //This method adds a new course
        private static void AddCourse()
        {
            bool courseIdAvailable = false;
            bool teacherExists = false;
            var courseID = 0;
            var teacherID = 0;
            /*do
            {
                //Reads the user's input for the course ID
                //Console.WriteLine("Enter course ID:\n");
                //courseID = ReadChoice();
                //If the course already exists, loops until the user inputs a valid, unique course ID
                if (bl.GetCourseByID(courseID) != null)
                {
                    Console.WriteLine("\nID already in use, try again!\n");
                }
                else
                {
                    courseIdAvailable = true;
                }
            } while (!courseIdAvailable);*/
            //Reads the user's input for the course name
            Console.WriteLine("Enter course name:\n");
            var courseName = Console.ReadLine();
            do
            {
                //Reads the user's input for the teacher ID
                Console.WriteLine("Enter teacher ID:");
                teacherID = ReadChoice();
                //If the teacher ID does not exist, loops until the user gives a valid teacher ID
                if (bl.GetTeacherByID(teacherID) == null)
                {
                    Console.WriteLine("\nTeacher does not exist, try again!");
                }
                else
                {
                    teacherExists = true;
                }
            } while (!teacherExists);

            //Creates a Course object and adds the object to the list of courses
            Course c = new Course
            {
                CourseId = courseID,
                CourseName = courseName,
                TeacherId = teacherID,
                Location = null
            };
            bl.AddCourse(c);
            unitOfWork.Save();

            Console.WriteLine("\nCourse {0} created!", courseName);
        }
        //This method updates a pre-existing teacher
        private static void UpdateTeacher()
        {
            var updateOption = 0;
            do
            {
                //Reads the user's input of whether they want to update the teacher by their ID or name
                Console.WriteLine("[    Updating Teacher Table     ]\n" +
                                  "1. Update teacher by ID\n" +
                                  "2. Update teacher by name");
                updateOption = ReadChoice();
                //loops until the user gives a valid input
            } while (updateOption != 1 && updateOption != 2);
            //Updating by teacher ID
            if (updateOption == 1)
            {
                //Reads the user's input for the teacher ID
                Console.WriteLine("Search teacher ID:\n");
                var teacherID = ReadChoice();
                var teacher = bl.GetTeacherByID(teacherID);
                if(teacher == null)
                {
                    Console.WriteLine("Teacher does not exist!\n");
                }
                else
                {
                    var innerUpdateOption = 0;
                    do
                    {
                        //Reads user input for updating the teacher by name or standard ID
                        Console.WriteLine("[    Updating Teacher Table     ]\n" +
                                      "1. Update teacher name\n" +
                                      "2. Update teacher standard");
                        innerUpdateOption = ReadChoice();
                        //loops until valid input
                    } while (innerUpdateOption != 1 && innerUpdateOption != 2);
                    //Updates teacher's name
                    if (innerUpdateOption == 1)
                    {
                        Console.WriteLine("Enter name:\n");
                        teacher.TeacherName = Console.ReadLine();
                    }
                    //Updates teacher's standard ID
                    else
                    {
                        bool standardExists = false;
                        var standardID = 0;
                        do
                        {
                            Console.WriteLine("Enter standard ID:\n");
                            standardID = ReadChoice();
                            if (bl.GetStandardByID(standardID) == null)
                            {
                                Console.WriteLine("\nStandard does not exist, try again!");
                            }
                            else
                            {
                                standardExists = true;
                            }
                        } while (!standardExists);
                        teacher.StandardId = standardID;
                    }
                    bl.UpdateTeacher(teacher);
                    unitOfWork.Save();
                    Console.WriteLine("\nTeacher {0} updated!", teacher.TeacherName);
                }

            }
            //Updates teacher by name
            else
            {
                Console.WriteLine("Search teacher name:\n");
                var teacherName = Console.ReadLine();
                var teachers = bl.GetTeachersByName(teacherName);
                if (teachers == null)
                {
                    Console.WriteLine("Teacher does not exist!\n");
                }
                else
                {
                    var innerUpdateOption = 0;
                    do
                    {
                        Console.WriteLine("[    Updating Teacher Table     ]\n" +
                                      "1. Update teacher name\n" +
                                      "2. Update teacher standard");
                        innerUpdateOption = ReadChoice();
                    } while (innerUpdateOption != 1 && innerUpdateOption != 2);
                    //Updates the teachers name
                    if (innerUpdateOption == 1)
                    {
                        Console.WriteLine("Enter name:\n");
                        var newName = Console.ReadLine();
                        foreach (Teacher teacher in teachers.ToList())  
                        {
                            teacher.TeacherName = newName;
                            bl.UpdateTeacher(teacher);
                        }
                    }
                    //Updates the teacher's standard ID
                    else
                    {
                        bool standardExists = false;
                        var standardID = 0;
                        do
                        {
                            Console.WriteLine("Enter standard ID:\n");
                            standardID = ReadChoice();
                            if (bl.GetStandardByID(standardID) == null)
                            {
                                Console.WriteLine("\nStandard does not exist, try again!");
                            }
                            else
                            {
                                standardExists = true;
                            }
                        } while (!standardExists);
                        foreach (Teacher teacher in teachers.ToList())
                        {
                            teacher.StandardId = standardID;
                            bl.UpdateTeacher(teacher);
                            unitOfWork.Save();
                        }
                    }
                }
                Console.WriteLine("\nTeacher {0} updated!", teachers.Count());
            }

        }
        //This method updates a course
        private static void UpdateCourse()
        {
            var updateOption = 0;
            do
            {
                Console.WriteLine("[    Updating Course Table     ]\n" +
                                  "1. Update course by ID\n" +
                                  "2. Update course by name");
                updateOption = ReadChoice();
            } while (updateOption != 1 && updateOption != 2);
            //Updates the course by ID
            if (updateOption == 1)
            {
                Console.WriteLine("Search course ID:\n");
                var courseID = ReadChoice();
                var course = bl.GetCourseByID(courseID);
                //Must be an existing course
                if (course == null)
                {
                    Console.WriteLine("course does not exist!\n");
                }
                else
                {
                    var innerUpdateOption = 0;
                    do
                    {
                        Console.WriteLine("[    Updating Course Table     ]\n" +
                                      "1. Update course name\n" +
                                      "2. Update course teacher");
                        innerUpdateOption = ReadChoice();
                    } while (innerUpdateOption != 1 && innerUpdateOption != 2);
                    //updates the course name
                    if (innerUpdateOption == 1)
                    {
                        Console.WriteLine("Enter name:\n");
                        course.CourseName = Console.ReadLine();
                    }
                    //updates the course ID
                    else
                    {
                        var teacherExists = false;
                        var teacherID = 0;
                        do
                        {
                            Console.WriteLine("Enter teacher ID:\n");
                            teacherID = ReadChoice();
                            if (bl.GetTeacherByID(teacherID) == null)
                            {
                                Console.WriteLine("\nTeacher does not exist, try again!");
                            }
                            else
                            {
                                teacherExists = true;
                            }
                        } while (!teacherExists);
                        course.TeacherId = teacherID;
                    }
                    bl.UpdateCourse(course);
                    unitOfWork.Save();
                    Console.WriteLine("\nCourse {0} updated!", course.CourseName);
                }

            }
            //Updates the course by name
            else
            {
                Console.WriteLine("Search course name:\n");
                var courseName = Console.ReadLine();
                var courses = bl.GetCoursesByName(courseName);
                //must be a pre-existing course
                if (courses == null)
                {
                    Console.WriteLine("Course does not exist!\n");
                }
                else
                {
                    var innerUpdateOption = 0;
                    do
                    {
                        Console.WriteLine("[    Updating Course Table     ]\n" +
                                      "1. Update course name\n" +
                                      "2. Update course teacher ID");
                        innerUpdateOption = ReadChoice();
                    } while (innerUpdateOption != 1 && innerUpdateOption != 2);
                    if (innerUpdateOption == 1)
                    {
                        Console.WriteLine("Enter course name:\n");
                        var newName = Console.ReadLine();
                        foreach (Course course in courses.ToList())
                        {
                            course.CourseName = newName;
                            bl.UpdateCourse(course);
                            unitOfWork.Save();
                        }
                    }
                    else
                    {
                        bool teacherExists = false;
                        var teacherID = 0;
                        do
                        {
                            Console.WriteLine("Enter teacher ID:\n");
                            teacherID = ReadChoice();
                            if (bl.GetTeacherByID(teacherID) == null)
                            {
                                Console.WriteLine("\nTeacher does not exist, try again!");
                            }
                            else
                            {
                                teacherExists = true;
                            }
                        } while (!teacherExists);
                        //Updates each course
                        foreach (Course course in courses.ToList())
                        {
                            course.TeacherId = teacherID;
                            bl.UpdateCourse(course);
                            unitOfWork.Save();
                        }
                    }
                }
                Console.WriteLine("\nCourse {0} updated!", courses.Count());
            }
        }

        //This method removes a pre-existing teacher
        private static void DeleteTeacher()
        {
            //Deletes by the teacher id
            Console.WriteLine("Enter teacher ID:\n");
            var teacherID = ReadChoice();
            var teacher = bl.GetTeacherByID(teacherID);
            if (teacher == null)
            {
                Console.WriteLine("Teacher does not exist!\n");
            }
            else
            {
                bl.RemoveTeacher(teacher);
                unitOfWork.Save();
                Console.WriteLine("Teacher {0} deleted!", teacher.TeacherName);
            }
        }

        //This method removes a pre-existing course
        private static void DeleteCourse()
        {
            //Deletes by course ID
            Console.WriteLine("Enter course ID:\n");
            var courseID = ReadChoice();
            var course = bl.GetCourseByID(courseID);
            if (course == null)
            {
                Console.WriteLine("Course does not exist!\n");
            }
            else
            {
                bl.RemoveCourse(course);
                unitOfWork.Save();
                Console.WriteLine("Course {0} deleted!", course.CourseName);
            }
        }

        //Displays the courses by the teacher's ID
        private static void DisplayCoursesByTeacherID()
        {
            Console.WriteLine("Enter Teacher ID");
            var teacherID = ReadChoice();
            var teacher = bl.GetTeacherByID(teacherID);
            //Must be a pre-existing teacher
            if (teacher == null)
            {
                Console.WriteLine("Teacher does not exist!\n");
            }
            else
            {
                var courses = bl.GetCoursesByTeacher(teacherID);
                Console.WriteLine("{0,-15}{1,-15}", "ID", "Name");
                //Displays all courses in the list
                foreach (Course course in courses.ToList())
                {
                    Console.WriteLine("{0,-15}{1,-15}", course.CourseId, course.CourseName);
                }

            }
        }
    }



}
