﻿using DataAccessLayer;
using System.Collections.Generic;
using System.Linq;
using System;

namespace BusinessLayer
{
    public class BusinessLayer : IBusinessLayer
    {
        private UnitOfWork UnitOfWork;
        /*
        private readonly IStandardRepository _standardRepository;
        private readonly IStudentRepository _studentRepository;
        private readonly ITeacherRepository _teacherRepository;
        private readonly ICourseRepository _courseRepository;
        */
        public BusinessLayer(UnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }
        /*
        public BusinessLayer()
        {
            _standardRepository = new StandardRepository();
            _studentRepository = new StudentRepository();
            _teacherRepository = new TeacherRepository();
            _courseRepository = new CourseRepository();

        }
        */
        #region Standard
        public IEnumerable<Standard> GetAllStandards()
        {
            return UnitOfWork.Standard.GetAll();
        }

        public Standard GetStandardByID(int id)
        {
            return UnitOfWork.Standard.GetById(id);
        }

        public Standard GetStandardByName(string name)
        {
            return UnitOfWork.Standard.GetSingle(
                s => s.StandardName.Equals(name),
                s => s.Students);
        }

        public void AddStandard(Standard standard)
        {
            UnitOfWork.Standard.Insert(standard);
        }

        public void UpdateStandard(Standard standard)
        {
            UnitOfWork.Standard.Update(standard);
        }

        public void RemoveStandard(Standard standard)
        {
            UnitOfWork.Standard.Delete(standard);
        }

        public Standard GetStandardByIDWithStudents(int id)
        {
            return UnitOfWork.Standard.GetSingle(
                s => s.StandardId == id,
                s => s.Students);
        }
        #endregion

        #region Student
        public IEnumerable<Student> GetAllStudents()
        {
            return UnitOfWork.Student.GetAll();
        }

        public Student GetStudentByID(int id)
        {
            return UnitOfWork.Student.GetById(id);
        }

        public void AddStudent(Student student)
        {
            UnitOfWork.Student.Insert(student);
        }

        public void UpdateStudent(Student student)
        {
            UnitOfWork.Student.Update(student);
        }

        public void RemoveStudent(Student student)
        {
            UnitOfWork.Student.Delete(student);
        }
        #endregion

        #region Teacher
        public IEnumerable<Teacher> GetAllTeachers()
        {
            return UnitOfWork.Teacher.GetAll();
        }

        public Teacher GetTeacherByID(int id)
        {
            return UnitOfWork.Teacher.GetById(id);
        }

        public void AddTeacher(Teacher teacher)
        {
            UnitOfWork.Teacher.Insert(teacher);
        }

        public void UpdateTeacher(Teacher teacher)
        {
            UnitOfWork.Teacher.Update(teacher);
        }

        public void RemoveTeacher(Teacher teacher)
        {
            UnitOfWork.Teacher.Delete(teacher);
        }
        public IEnumerable<Teacher> GetTeachersByName(string name)
        {
            return UnitOfWork.Teacher.SearchFor(teacher => teacher.TeacherName == name);
        }
        #endregion

        #region Courses
        public IEnumerable<Course> GetAllCourses()
        {
            return UnitOfWork.Course.GetAll();
        }

        public Course GetCourseByID(int id)
        {
            return UnitOfWork.Course.GetById(id);
        }

        public IEnumerable<Course> GetCoursesByTeacher(int id)
        {
            return UnitOfWork.Course.SearchFor(course => course.TeacherId == id);
        }

        public void AddCourse(Course course)
        {
            UnitOfWork.Course.Insert(course);
        }

        public void UpdateCourse(Course course)
        {
            UnitOfWork.Course.Update(course);
        }

        public void RemoveCourse(Course course)
        {
            UnitOfWork.Course.Delete(course);
        }
        public IEnumerable<Course> GetCoursesByName(string name)
        {
            return UnitOfWork.Course.SearchFor(courses => courses.CourseName == name);
        }
        #endregion

    }
}