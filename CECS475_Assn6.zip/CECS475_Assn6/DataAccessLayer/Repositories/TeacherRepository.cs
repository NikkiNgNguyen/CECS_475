﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class TeacherRepository : Repository<Teacher>, ITeacherRepository
    {
        public TeacherRepository() : base(new SchoolDBEntities())
        {

        }
        public TeacherRepository(SchoolDBEntities context) : base(context)
        {

        }
        public SchoolDBEntities DbContext
        {
            get { return Context as SchoolDBEntities; }
        }
    }
}