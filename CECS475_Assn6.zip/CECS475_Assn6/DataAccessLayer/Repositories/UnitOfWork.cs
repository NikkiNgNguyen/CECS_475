﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity;
using System.Linq.Expressions;

namespace DataAccessLayer
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SchoolDBEntities _context;
        public IStandardRepository Standard { get; }
        public IStudentRepository Student { get; }
        public ITeacherRepository Teacher { get; }
        public ICourseRepository Course { get; }

        public UnitOfWork(SchoolDBEntities context)
        {
            _context = context;
            Standard = new StandardRepository(_context);
            Student = new StudentRepository(_context);
            Teacher = new TeacherRepository(_context);
            Course = new CourseRepository(_context);

        }
        public int Save()
        {
            return _context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}

        /* private StandardRepository _standard;
         private StudentRepository _student;
         private TeacherRepository _teacher;
         private CourseRepository _course;

         public UnitOfWork()
         {
         }

         public UnitOfWork(DbContext context)
         {
             _context = context;

         }

         public StandardRepository Standard
         {
             get
             {

                 if (_standard == null)
                 {
                     _standard = new StandardRepository(_context);
                 }
                 return _standard;
             }

         }
         public StudentRepository Student
         {
             get
             {

                 if (_student == null)
                 {
                     _student = new StudentRepository(_context);
                 }
                 return _student;
             }
         }
         public TeacherRepository Teacher
         {
             get
             {

                 if (_teacher == null)
                 {
                     _teacher = new TeacherRepository(_context);
                 }
                 return _teacher;
             }

         }
         public CourseRepository Course
         {
             get
             {

                 if (_course == null)
                 {
                     _course = new CourseRepository(_context);
                 }
                 return _course;
             }
         }

         IStandardRepository IUnitOfWork.Standard => throw new NotImplementedException();

         IStudentRepository IUnitOfWork.Student => throw new NotImplementedException();

         ITeacherRepository IUnitOfWork.Teacher => throw new NotImplementedException();

         ICourseRepository IUnitOfWork.Course => throw new NotImplementedException();

         public int Save()
         {
            return _context.SaveChanges();
         }

         private bool disposed = false;

         protected virtual void Dispose(bool disposing)
         {
             if (!this.disposed)
             {
                 if (disposing)
                 {
                     _context.Dispose();
                 }
             }
             this.disposed = true;
         }
         public void Dispose()
         {
             Dispose(true);
             GC.SuppressFinalize(this);
         }

     }

}*/
