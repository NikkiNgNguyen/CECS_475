﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class StudentRepository : Repository<Student>, IStudentRepository
    {
        public StudentRepository() : base(new SchoolDBEntities())
        {

        }
        public StudentRepository(SchoolDBEntities context) : base(context)
        {

        }
        public SchoolDBEntities DbContext
        {
            get { return Context as SchoolDBEntities; }
        }
    }
}
