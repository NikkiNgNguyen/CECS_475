﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class StandardRepository : Repository<Standard>, IStandardRepository
    {
        public StandardRepository() : base(new SchoolDBEntities())
        {

        }
        public StandardRepository(SchoolDBEntities context) : base (context)
        {

        }
        public SchoolDBEntities DbContext
        {
            get { return Context as SchoolDBEntities; }
        }
    }
}
