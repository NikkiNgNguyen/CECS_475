﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity;
using System.Linq.Expressions;

namespace DataAccessLayer
{
    public interface IUnitOfWork : IDisposable
    {
        IStandardRepository Standard { get; }
        IStudentRepository Student { get; }
        ITeacherRepository Teacher { get; }
        ICourseRepository Course { get; }
        int Save();


    }
}
