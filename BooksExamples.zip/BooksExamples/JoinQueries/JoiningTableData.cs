﻿// JoiningTableData.cs
// Using LINQ to perform a join and aggregate data across tables.
using System;
using System.Linq;
using System.Windows.Forms;

namespace JoinQueries
{
    public partial class JoiningTableData : Form
    {
        public JoiningTableData()
        {
            InitializeComponent();
        } // end constructor

        private void JoiningTableData_Load(object sender, EventArgs e)
        {
            // Entity Framework DBContext
            BooksEntities dbcontext =
               new BooksEntities();

            // get titles and authors sorted by title
            var titlesAndAuthors =
               from book in dbcontext.Titles
               from author in book.Authors
               orderby book.Title1
               select new
               {
                   Name = author.FirstName + " " + author.LastName,
                   book.Title1,
               };
            outputTextBox.AppendText("\r\n\r\nTitles and Authors:");
            foreach(var element in titlesAndAuthors)
            {
                outputTextBox.AppendText(
                    String.Format("\r\n\t" + element.Title1 + " " + element.Name));
            }
            // get titles and authors sorted by last name then first name
            var authorsAndTitles =
               from book in dbcontext.Titles
               from author in book.Authors
               orderby book.Title1, author.LastName, author.FirstName
               select new
               {
                   book.Title1,
                   author.FirstName,
                   author.LastName
               };

            outputTextBox.AppendText("\r\n\r\nAuthors and titles with authors sorted for each title:");

            // display authors and titles in tabular format
            foreach (var element in authorsAndTitles)
            {
                outputTextBox.AppendText(
                   String.Format("\r\n\t" +
                      element.Title1 + " " + element.FirstName + " " + element.LastName));
            } // end foreach

            // get authors grouped by title sorted by last then first name 
            // they co-authored; group by author
            var titlesByAuthor =
               from book in dbcontext.Titles
               orderby book.Title1
               select new
               {
                  bookTitle = book.Title1,
                   Author =
                    from author in book.Authors
                    orderby author.LastName, author.FirstName
                    select new { author.LastName, author.FirstName }
               };

            outputTextBox.AppendText("\r\n\r\nTitles grouped by author:");

            foreach (var title in titlesByAuthor)
            {
                outputTextBox.AppendText("\r\n\t" + title.bookTitle + ":");
                foreach (var author in title.Author)
                {
                    outputTextBox.AppendText("\r\n\t\t" + author.FirstName + " " + author.LastName);
                }
            }    

        } // end method JoiningTableData_Load
    } // end class JoiningTableData
} // end namespace JoinQueries

